
package model.bean;

/**
 *
 * @author jarde
 */
public class Professor {
    private int id;
    private String Nome;
    private String CPF;
    private String Email;
    private String Sexo;
    private String Curso;
    private String Periodo;
    private String Celular;
    private String Eixo;
    private String Disciplinas;
    private String Nascimento;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return Nome;
    }

    public void setNome(String Nome) {
        this.Nome = Nome;
    }
     public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }
    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }
    public String getSexo() {
        return Sexo;
    }

    public void setSexo(String Sexo) {
        this.Sexo = Sexo;
    }
    public String getCurso() {
        return Curso;
    }

    public void setCurso(String Curso) {
        this.Curso = Curso;
    }
    public String getPeriodo() {
        return Periodo;
    }

    public void setPeriodo(String Periodo) {
        this.Periodo = Periodo;
    }
    public String getCelular() {
        return Celular;
    }

    public void setCelular(String Celular) {
        this.Celular = Celular;
    }
    public String getEixo() {
        return Eixo;
    }

    public void setEixo(String Eixo) {
        this.Eixo = Eixo;
    }
    public String getDisciplinas() {
        return Disciplinas;
    }

    public void setDisciplinas(String Disciplinas) {
        this.Disciplinas = Disciplinas;
    }
    public String getNascimento() {
        return Nascimento;
    }

    public void setNascimento(String Nascimento) {
        this.Nascimento = Nascimento;
    }
    
}
